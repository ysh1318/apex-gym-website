import { useInView } from '../hooks/useInView'
import { useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

const testimonials = [
  {
    name: 'Rahul Mehta',
    role: 'Lost 18kg in 5 months',
    quote: 'APEX completely changed how I see fitness. The trainers here don\'t just put you through workouts — they rebuild your mindset. I came in insecure and left with a body and confidence I never thought I\'d have.',
    img: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=200&q=80',
  },
  {
    name: 'Ananya Krishnan',
    role: 'Gained 8kg lean muscle',
    quote: 'The programming at APEX is genuinely different. Science-backed, progressive, and coached by people who have been through it themselves. Best investment I\'ve made in myself.',
    img: 'https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=200&q=80',
  },
  {
    name: 'Vikram Singh',
    role: 'Prep athlete — 12 weeks',
    quote: 'I\'ve trained in gyms across the country. None come close to the atmosphere and expertise here. APEX is the real deal for anyone serious about transformation.',
    img: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&q=80',
  },
  {
    name: 'Sneha Pillai',
    role: 'Fitness enthusiast — 1yr',
    quote: 'The community here is what keeps me coming back. Everyone pushes each other. The trainers remember your goals. It\'s a premium experience from the moment you walk in.',
    img: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=200&q=80',
  },
]

export default function Testimonials() {
  const [ref, inView] = useInView()
  const [active, setActive] = useState(0)

  const prev = () => setActive((a) => (a - 1 + testimonials.length) % testimonials.length)
  const next = () => setActive((a) => (a + 1) % testimonials.length)

  return (
    <section className="py-32 lg:py-48 bg-apex-ivory relative overflow-hidden" ref={ref}>
      {/* Large background numeral — editorial flair */}
      <div className="absolute right-10 top-1/2 -translate-y-1/2 pointer-events-none select-none opacity-[0.025]">
        <span className="font-display text-[20rem] font-light text-apex-charcoal leading-none">
          {String(active + 1).padStart(2, '0')}
        </span>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <div className={`mb-16 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <p className="section-label">Client Stories</p>
          <div className="flex items-end justify-between gap-6">
            <h2 className="section-title text-[clamp(3rem,5vw,5rem)] text-apex-charcoal leading-none">
              Words from<br />
              <em className="italic text-apex-bronze">Our Tribe</em>
            </h2>

            {/* Navigation */}
            <div className="flex gap-2 shrink-0">
              <button
                onClick={prev}
                className="w-11 h-11 border border-apex-charcoal/12 flex items-center justify-center hover:border-apex-charcoal/35 hover:bg-apex-cream transition-all duration-200"
              >
                <ChevronLeft size={14} className="text-apex-charcoal/50" />
              </button>
              <button
                onClick={next}
                className="w-11 h-11 border border-apex-charcoal/12 flex items-center justify-center hover:border-apex-bronze/50 hover:bg-apex-bronze/5 transition-all duration-200"
              >
                <ChevronRight size={14} className="text-apex-charcoal/50" />
              </button>
            </div>
          </div>
        </div>

        {/* Cards */}
        <div className="grid lg:grid-cols-2 gap-3">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className={`editorial-card p-8 lg:p-10 relative overflow-hidden cursor-pointer transition-all duration-500 ${
                inView ? 'translate-y-0' : 'translate-y-10'
              }`}
              style={{ transitionDelay: `${i * 70}ms`, opacity: inView ? (i === active ? 1 : 0.4) : 0 }}
              onClick={() => setActive(i)}
            >
              {/* Active accent */}
              {i === active && <div className="absolute top-0 left-0 w-10 h-0.5 bg-apex-bronze" />}

              {/* Large quote mark */}
              <div className="font-display text-6xl text-apex-bronze/25 leading-none mb-2 font-light">"</div>

              <p className="font-body text-sm text-apex-charcoal/60 leading-loose font-light mb-8 italic">
                {t.quote}
              </p>

              <div className="flex items-center gap-4">
                <img
                  src={t.img}
                  alt={t.name}
                  className="w-10 h-10 rounded-full object-cover grayscale"
                />
                <div>
                  <div className="font-heading text-xs font-medium tracking-wider uppercase text-apex-charcoal">{t.name}</div>
                  <div className="font-heading text-[10px] tracking-wider uppercase text-apex-bronze/75 mt-0.5">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Dots */}
        <div className={`flex gap-2 mt-8 justify-center transition-all duration-700 delay-400 ${inView ? 'opacity-100' : 'opacity-0'}`}>
          {testimonials.map((_, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`transition-all duration-300 rounded-full ${
                i === active ? 'w-5 h-1.5 bg-apex-bronze' : 'w-1.5 h-1.5 bg-apex-charcoal/15 hover:bg-apex-charcoal/30'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
