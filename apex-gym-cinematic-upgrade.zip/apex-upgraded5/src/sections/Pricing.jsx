import { useInView } from '../hooks/useInView'
import { Check, ArrowRight } from 'lucide-react'

const plans = [
  {
    name: 'Monthly',
    price: '2,999',
    period: '/month',
    desc: 'Perfect for those starting their journey',
    features: [
      'Full gym access (6AM–11PM)',
      '2 group classes per week',
      'Fitness assessment',
      'Locker & shower access',
      'App progress tracking',
    ],
    cta: 'Start Monthly',
    featured: false,
  },
  {
    name: 'Quarterly',
    price: '7,999',
    period: '/3 months',
    desc: 'Commit deeper. Results compound.',
    features: [
      'Everything in Monthly',
      'Unlimited group classes',
      'Monthly check-in with coach',
      'Nutrition guidance',
      'Priority class booking',
      'Guest passes (2/month)',
    ],
    cta: 'Join Quarterly',
    featured: true,
    badge: 'Most Popular',
  },
  {
    name: 'Annual',
    price: '24,999',
    period: '/year',
    desc: 'The full APEX experience. Uncompromised.',
    features: [
      'Everything in Quarterly',
      'Personal training (4 sessions)',
      'Body composition analysis',
      'Recovery zone access',
      'Merchandise credit ₹2,000',
      'VIP event access',
    ],
    cta: 'Go Annual',
    featured: false,
  },
]

export default function Pricing() {
  const [ref, inView] = useInView()

  return (
    <section id="pricing" className="py-32 lg:py-48 bg-apex-cream" ref={ref}>
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <div className={`text-center mb-20 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <p className="section-label">Membership Plans</p>
          <h2 className="section-title text-[clamp(3rem,6vw,6rem)] text-apex-charcoal leading-none mb-6">
            Choose Your<br />
            <em className="italic text-apex-bronze">Commitment</em>
          </h2>
          <p className="font-body text-sm text-apex-charcoal/55 max-w-md mx-auto leading-relaxed font-light">
            Every plan includes access to elite facilities. The question is how deep you want to go.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-3 lg:gap-4">
          {plans.map((plan, i) => (
            <PricingCard key={plan.name} {...plan} delay={i * 100} inView={inView} />
          ))}
        </div>

        <div className={`mt-10 text-center transition-all duration-700 delay-500 ${inView ? 'opacity-100' : 'opacity-0'}`}>
          <p className="font-body text-xs text-apex-charcoal/40">
            All prices include GST. No hidden fees. Cancel anytime on monthly plan.
          </p>
        </div>
      </div>
    </section>
  )
}

function PricingCard({ name, price, period, desc, features, cta, featured, badge, delay, inView }) {
  return (
    <div
      className={`relative flex flex-col transition-all duration-700 ${
        inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      } ${featured ? 'lg:-mt-4' : ''}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {featured && badge && (
        <div className="bg-apex-charcoal text-center py-2.5 px-6">
          <span className="font-heading text-[10px] tracking-[0.3em] uppercase text-apex-ivory/70">{badge}</span>
        </div>
      )}

      <div className={`flex-1 p-8 lg:p-10 flex flex-col transition-all duration-300 ${
        featured
          ? 'bg-apex-charcoal border border-apex-charcoal'
          : 'editorial-card'
      }`}>
        {/* Header */}
        <div className={`mb-8 pb-8 border-b ${featured ? 'border-apex-ivory/10' : 'border-apex-charcoal/10'}`}>
          <h3 className={`font-heading text-[10px] tracking-[0.3em] uppercase mb-6 ${featured ? 'text-apex-ivory/55' : 'text-apex-charcoal/50'}`}>{name}</h3>
          <div className="flex items-baseline gap-1 mb-2">
            <span className={`font-display text-6xl font-light ${featured ? 'text-apex-ivory' : 'text-apex-charcoal'}`}>₹{price}</span>
            <span className={`font-heading text-xs ${featured ? 'text-apex-ivory/45' : 'text-apex-charcoal/45'}`}>{period}</span>
          </div>
          <p className={`font-body text-xs leading-relaxed font-light ${featured ? 'text-apex-ivory/55' : 'text-apex-charcoal/55'}`}>{desc}</p>
        </div>

        {/* Features */}
        <ul className="flex flex-col gap-3 mb-10 flex-1">
          {features.map((f) => (
            <li key={f} className="flex items-start gap-3">
              <Check size={11} className={`mt-0.5 shrink-0 ${featured ? 'text-apex-bronze' : 'text-apex-bronze/60'}`} />
              <span className={`font-body text-sm font-light ${featured ? 'text-apex-ivory/75' : 'text-apex-charcoal/55'}`}>{f}</span>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <button className={`w-full py-4 font-heading text-[11px] tracking-[0.22em] uppercase flex items-center justify-center gap-3 transition-all duration-300 ${
          featured
            ? 'bg-apex-ivory text-apex-charcoal hover:bg-apex-cream'
            : 'border border-apex-charcoal/20 hover:border-apex-charcoal/50 text-apex-charcoal/70 hover:text-apex-charcoal'
        }`}>
          {cta} <ArrowRight size={12} />
        </button>
      </div>
    </div>
  )
}
