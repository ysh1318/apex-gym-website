import { useInView } from '../hooks/useInView'

const images = [
  { src: 'https://images.unsplash.com/photo-1605296867424-35fc25c9212a?w=600&q=80', tall: true, label: 'Power Training' },
  { src: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=600&q=80', tall: false, label: 'Athletic Performance' },
  { src: 'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?w=600&q=80', tall: false, label: 'Strength & Form' },
  { src: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=600&q=80', tall: true, label: 'Elite Conditioning' },
  { src: 'https://images.unsplash.com/photo-1532029837206-abbe2b7620e3?w=600&q=80', tall: false, label: 'Mental Focus' },
  { src: 'https://images.unsplash.com/photo-1576678927484-cc907957088c?w=600&q=80', tall: false, label: 'Results Culture' },
]

export default function Gallery() {
  const [ref, inView] = useInView()

  return (
    <section className="relative py-24 lg:py-40 overflow-hidden" ref={ref}>
      {/* Mid-tone cinematic background — between ivory sections */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0" style={{ background: '#ECEAE4' }} />
        <div
          className="absolute inset-0 opacity-[0.06]"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=1400&q=40')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'grayscale(100%)',
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-16 relative z-10">
        <div className={`flex flex-col lg:flex-row lg:items-end justify-between mb-14 gap-6 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div>
            <p className="section-label">The Space</p>
            <h2 className="section-title text-[clamp(3rem,6vw,6rem)] text-apex-charcoal leading-none">
              Where Results<br />
              <em className="italic text-apex-bronze">Live</em>
            </h2>
          </div>
          <p className="font-body text-sm text-apex-charcoal/55 max-w-xs leading-relaxed font-light">
            Real training. Real intensity. Real transformation happening every day inside APEX.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
          {images.map((img, i) => (
            <div
              key={i}
              className={`group relative overflow-hidden bg-apex-stone/30 transition-all duration-700 ${
                inView ? 'opacity-100' : 'opacity-0'
              }`}
              style={{
                transitionDelay: `${i * 70}ms`,
                aspectRatio: img.tall ? '3/4' : '4/3',
              }}
            >
              <img
                src={img.src}
                alt={img.label}
                className="w-full h-full object-cover group-hover:scale-105 transition-all duration-700"
                style={{ filter: 'grayscale(30%) sepia(10%) saturate(80%) contrast(1.05)' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-apex-ink/55 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-400">
                <span className="font-heading text-[10px] tracking-[0.25em] uppercase text-apex-ivory/80">{img.label}</span>
              </div>
              <div className="absolute top-0 left-0 w-0 h-0.5 bg-apex-bronze group-hover:w-2/3 transition-all duration-500" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
