import { useInView } from '../hooks/useInView'

export default function About() {
  const [ref, inView] = useInView()

  const pillars = [
    { num: '01', title: 'Elite Coaching', desc: 'Certified coaches who have trained champions. Every session is precision-engineered for results.' },
    { num: '02', title: 'Premium Facilities', desc: 'State-of-the-art equipment. Exclusive recovery zones. A space built for serious athletes.' },
    { num: '03', title: 'Scientific Method', desc: 'Programming backed by sports science. Your body adapts — your results compound.' },
  ]

  return (
    <section id="about" className="relative py-24 lg:py-40 overflow-hidden">
      {/* Cinematic atmospheric background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-apex-ivory" />
        {/* Subtle photographic depth layer */}
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=1400&q=60&auto=format&fit=crop')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'grayscale(100%) contrast(1.2)',
          }}
        />
        {/* Gradient mask over photo */}
        <div className="absolute inset-0 bg-gradient-to-b from-apex-ivory/95 via-apex-ivory/80 to-apex-ivory/95" />
        {/* Architectural right accent */}
        <div className="absolute right-0 top-0 bottom-0 w-px bg-apex-charcoal/8" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-16 relative z-10" ref={ref}>
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-32 items-start">

          {/* Left: headline block */}
          <div>
            <div className={`transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
              <p className="section-label">Our Philosophy</p>
              <h2 className="section-title text-[clamp(3rem,7vw,7rem)] text-apex-charcoal leading-none mb-8">
                Not a gym.<br />
                <em className="italic text-apex-bronze" style={{ fontStyle: 'italic' }}>A movement.</em>
              </h2>
            </div>

            <div className={`transition-all duration-700 delay-150 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
              <p className="font-body text-apex-charcoal/60 text-sm leading-loose max-w-md mb-8 font-light">
                APEX was built for those who refuse mediocrity. We exist for the disciplined — those who understand that transformation is earned, not given. Every detail of this space was designed to bring out the best version of you.
              </p>

              <div className="flex items-center gap-4">
                <div className="w-12 h-px bg-apex-bronze/40" />
                <span className="font-heading text-[10px] tracking-[0.3em] uppercase text-apex-charcoal/45">
                  Built for the relentless
                </span>
              </div>
            </div>
          </div>

          {/* Right: numbered pillars */}
          <div className="flex flex-col">
            {pillars.map((p, i) => (
              <div
                key={p.num}
                className={`group py-7 border-b border-apex-charcoal/6 flex gap-8 items-start transition-all duration-700 ${
                  inView ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
                }`}
                style={{ transitionDelay: `${i * 120}ms` }}
              >
                <span className="font-heading text-[10px] text-apex-bronze/50 mt-1 w-6 shrink-0 tracking-wider">{p.num}</span>
                <div>
                  <h3 className="font-heading text-sm font-medium tracking-[0.12em] uppercase text-apex-charcoal mb-2 group-hover:text-apex-bronze transition-colors">
                    {p.title}
                  </h3>
                  <p className="font-body text-sm text-apex-charcoal/55 leading-relaxed font-light">{p.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
