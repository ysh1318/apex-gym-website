import { useInView, useCounter } from '../hooks/useInView'

function StatItem({ end, suffix, label, delay, inView }) {
  const count = useCounter(end, 2000, inView)
  return (
    <div
      className={`text-center lg:text-left transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="font-display text-[clamp(3rem,6vw,6rem)] text-apex-ivory leading-none font-light tracking-tight">
        {count}{suffix}
      </div>
      <div className="font-heading text-[10px] tracking-[0.3em] uppercase text-apex-ivory/45 mt-2">{label}</div>
    </div>
  )
}

export default function Stats() {
  const [ref, inView] = useInView({ threshold: 0.3 })

  const stats = [
    { end: 2400, suffix: '+', label: 'Members Transformed' },
    { end: 98, suffix: '%', label: 'Retention Rate' },
    { end: 48, suffix: '', label: 'Elite Trainers' },
    { end: 12, suffix: 'yr', label: 'Years of Excellence' },
  ]

  return (
    <section className="relative py-24 overflow-hidden" ref={ref}>
      {/* Dark cinematic background */}
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=1600&q=70&auto=format&fit=crop')`,
            filter: 'brightness(0.3) contrast(1.1) grayscale(30%)',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-apex-ink/90 via-apex-ink/80 to-apex-ink/90" />
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 50% 50%, rgba(139,110,78,0.08) 0%, transparent 70%)' }} />
        {/* Top/bottom fade to ivory */}
        <div className="absolute top-0 left-0 right-0 h-16 bg-gradient-to-b from-apex-ivory to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-apex-ivory to-transparent" />
      </div>

      {/* Subtle decorative cross */}
      <div className="absolute right-16 top-1/2 -translate-y-1/2 opacity-[0.05] pointer-events-none select-none z-10">
        <div className="font-display text-[16rem] font-light text-apex-ivory leading-none">×</div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-16 relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-0 lg:divide-x divide-apex-ivory/8">
          {stats.map((s, i) => (
            <div key={s.label} className="lg:px-12 first:lg:pl-0 last:lg:pr-0">
              <StatItem {...s} delay={i * 100} inView={inView} />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
