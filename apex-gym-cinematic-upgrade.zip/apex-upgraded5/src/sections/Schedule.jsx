import { useState } from 'react'
import { useInView } from '../hooks/useInView'
import { Clock, Users } from 'lucide-react'

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

const schedule = {
  Mon: [
    { time: '06:00', name: 'Power Hour', trainer: 'Marcus', spots: 12, type: 'strength' },
    { time: '08:00', name: 'HIIT Blast', trainer: 'Priya', spots: 8, type: 'hiit' },
    { time: '10:00', name: 'Strength Fundamentals', trainer: 'Marcus', spots: 15, type: 'strength' },
    { time: '17:00', name: 'Combat Conditioning', trainer: 'Arjun', spots: 10, type: 'combat' },
    { time: '19:00', name: 'Evening HIIT', trainer: 'Priya', spots: 14, type: 'hiit' },
  ],
  Tue: [
    { time: '06:30', name: 'Mobility & Flow', trainer: 'Zara', spots: 12, type: 'mobility' },
    { time: '09:00', name: 'Boxing Drills', trainer: 'Arjun', spots: 8, type: 'combat' },
    { time: '11:00', name: 'Body Recomp', trainer: 'Priya', spots: 10, type: 'hiit' },
    { time: '18:00', name: 'Elite Strength', trainer: 'Marcus', spots: 12, type: 'strength' },
    { time: '20:00', name: 'Stretch & Recovery', trainer: 'Zara', spots: 15, type: 'mobility' },
  ],
  Wed: [
    { time: '06:00', name: 'Power Hour', trainer: 'Marcus', spots: 12, type: 'strength' },
    { time: '08:30', name: 'Metabolic Circuit', trainer: 'Priya', spots: 10, type: 'hiit' },
    { time: '10:00', name: 'Combat Fitness', trainer: 'Arjun', spots: 8, type: 'combat' },
    { time: '17:30', name: 'Olympic Lifting', trainer: 'Marcus', spots: 6, type: 'strength' },
    { time: '19:30', name: 'Evening Boxing', trainer: 'Arjun', spots: 10, type: 'combat' },
  ],
  Thu: [
    { time: '07:00', name: 'Functional Flow', trainer: 'Zara', spots: 12, type: 'mobility' },
    { time: '09:30', name: 'HIIT Endurance', trainer: 'Priya', spots: 14, type: 'hiit' },
    { time: '18:00', name: 'Strength & Power', trainer: 'Marcus', spots: 12, type: 'strength' },
    { time: '20:00', name: 'Night Conditioning', trainer: 'Priya', spots: 10, type: 'hiit' },
  ],
  Fri: [
    { time: '06:00', name: 'Power Hour', trainer: 'Marcus', spots: 12, type: 'strength' },
    { time: '08:00', name: 'HIIT Blast', trainer: 'Priya', spots: 8, type: 'hiit' },
    { time: '10:00', name: 'Boxing Masterclass', trainer: 'Arjun', spots: 8, type: 'combat' },
    { time: '17:00', name: 'Elite S&C', trainer: 'Marcus', spots: 10, type: 'strength' },
    { time: '19:00', name: 'Friday Burn', trainer: 'Priya', spots: 14, type: 'hiit' },
  ],
  Sat: [
    { time: '07:00', name: 'Weekend Warrior', trainer: 'Marcus', spots: 16, type: 'strength' },
    { time: '09:00', name: 'Combat Saturday', trainer: 'Arjun', spots: 12, type: 'combat' },
    { time: '11:00', name: 'Yoga & Mobility', trainer: 'Zara', spots: 15, type: 'mobility' },
    { time: '15:00', name: 'Open Training', trainer: 'All', spots: 20, type: 'hiit' },
  ],
  Sun: [
    { time: '08:00', name: 'Sunday Reset', trainer: 'Zara', spots: 15, type: 'mobility' },
    { time: '10:00', name: 'Group Strength', trainer: 'Marcus', spots: 12, type: 'strength' },
    { time: '16:00', name: 'Recovery Flow', trainer: 'Zara', spots: 12, type: 'mobility' },
  ],
}

const typePalette = {
  strength: { accent: '#2C2A27', label: 'bg-apex-charcoal/90' },
  hiit:     { accent: '#8B6E4E', label: 'bg-apex-bronze/90' },
  combat:   { accent: '#A07850', label: 'bg-apex-copper/90' },
  mobility: { accent: '#8A857D', label: 'bg-apex-fog/80' },
}

export default function Schedule() {
  const [activeDay, setActiveDay] = useState('Mon')
  const [ref, inView] = useInView()

  return (
    <section id="schedule" className="relative py-24 lg:py-40 overflow-hidden" ref={ref}>
      {/* Cinematic dark background with gym atmosphere */}
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=1600&q=70&auto=format&fit=crop')`,
            filter: 'brightness(0.2) grayscale(20%) contrast(1.1)',
          }}
        />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, #1A1916 0%, #1e1c18 50%, #1A1916 100%)' }} />
        <div className="absolute inset-0 opacity-60" style={{ background: 'radial-gradient(ellipse at 20% 50%, rgba(139,110,78,0.07) 0%, transparent 50%)' }} />
        {/* Top/bottom transitions */}
        <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-b from-apex-ivory to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-apex-ink to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-16 relative z-10">
        
        {/* Header */}
        <div className={`flex flex-col lg:flex-row lg:items-end justify-between mb-12 gap-6 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div>
            <p className="section-label" style={{ color: 'rgba(201,169,122,0.7)' }}>Weekly Schedule</p>
            <h2 className="section-title text-[clamp(3rem,5vw,5.5rem)] text-apex-ivory leading-none">
              Class<br />
              <em className="italic" style={{ color: '#C9A97A' }}>Timetable</em>
            </h2>
          </div>

          <div className="flex flex-wrap gap-5">
            {Object.entries({ strength: 'Strength', hiit: 'HIIT', combat: 'Combat', mobility: 'Mobility' }).map(([type, label]) => (
              <div key={type} className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: typePalette[type].accent }} />
                <span className="font-heading text-[10px] tracking-wider uppercase text-apex-ivory/40">{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Day tabs — more prominent */}
        <div className={`flex gap-1 mb-8 overflow-x-auto pb-2 transition-all duration-700 delay-200 ${inView ? 'opacity-100' : 'opacity-0'}`}>
          {days.map((day) => (
            <button
              key={day}
              onClick={() => setActiveDay(day)}
              className={`shrink-0 px-5 py-3.5 font-heading text-[11px] tracking-[0.2em] uppercase transition-all duration-200 ${
                activeDay === day
                  ? 'text-apex-charcoal'
                  : 'border border-apex-ivory/10 text-apex-ivory/30 hover:border-apex-ivory/25 hover:text-apex-ivory/60'
              }`}
              style={activeDay === day ? { background: '#C9A97A' } : {}}
            >
              {day}
            </button>
          ))}
        </div>

        {/* Class cards — dark, premium */}
        <div className={`grid sm:grid-cols-2 lg:grid-cols-3 gap-2 transition-all duration-700 delay-300 ${inView ? 'opacity-100' : 'opacity-0'}`}>
          {schedule[activeDay]?.map((cls) => (
            <ScheduleCard key={`${cls.time}-${cls.name}`} cls={cls} />
          ))}
        </div>
      </div>
    </section>
  )
}

function ScheduleCard({ cls }) {
  const palette = typePalette[cls.type]
  return (
    <div className="group schedule-card relative overflow-hidden cursor-pointer transition-all duration-300">
      {/* Left accent bar */}
      <div className="absolute left-0 top-0 bottom-0 w-0.5 transition-all duration-300 group-hover:w-1" style={{ background: palette.accent }} />

      <div className="pl-5 pr-5 pt-4 pb-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5" style={{ color: 'rgba(255,255,255,0.35)' }}>
            <Clock size={9} />
            <span className="font-heading text-[10px] tracking-wider">{cls.time}</span>
          </div>
          <div className="flex items-center gap-1" style={{ color: 'rgba(255,255,255,0.25)' }}>
            <Users size={9} />
            <span className="font-heading text-[10px]">{cls.spots}</span>
          </div>
        </div>

        <h4 className="font-display text-base font-light text-apex-ivory/85 group-hover:text-apex-ivory transition-colors mb-1">
          {cls.name}
        </h4>
        <p className="font-heading text-[9px] tracking-wider uppercase" style={{ color: 'rgba(255,255,255,0.30)' }}>{cls.trainer}</p>
      </div>
    </div>
  )
}
