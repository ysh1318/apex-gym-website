import { useInView } from '../hooks/useInView'
import { Instagram } from 'lucide-react'

const trainers = [
  {
    name: 'Marcus Reid',
    role: 'Strength & Power Coach',
    exp: '11yr',
    specialties: ['Olympic Lifting', 'Powerlifting', 'Athlete Prep'],
    img: 'https://images.unsplash.com/photo-1567013127542-490d757e51fc?w=600&q=80',
  },
  {
    name: 'Priya Sharma',
    role: 'Metabolic & Performance',
    exp: '8yr',
    specialties: ['HIIT', 'Body Recomp', 'Nutrition Coaching'],
    img: 'https://images.unsplash.com/photo-1609899537878-47b2f7a3bb1d?w=600&q=80',
  },
  {
    name: 'Arjun Kapoor',
    role: 'Combat & Conditioning',
    exp: '13yr',
    specialties: ['Boxing', 'MMA Conditioning', 'Agility Training'],
    img: 'https://images.unsplash.com/photo-1581803118522-7b72a50f7e9f?w=600&q=80',
  },
  {
    name: 'Zara Chen',
    role: 'Mobility & Recovery',
    exp: '9yr',
    specialties: ['Functional Movement', 'Injury Prevention', 'Yoga Flow'],
    img: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&q=80',
  },
]

export default function Trainers() {
  const [ref, inView] = useInView()

  return (
    <section id="trainers" className="py-32 lg:py-48 bg-apex-ivory" ref={ref}>
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <div className={`mb-20 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <p className="section-label">Our Coaches</p>
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <h2 className="section-title text-[clamp(3rem,6vw,6rem)] text-apex-charcoal leading-none">
              Expert<br />
              <em className="italic text-apex-bronze">Elite</em><br />
              Trainers
            </h2>
            <p className="font-body text-sm text-apex-charcoal/55 max-w-xs leading-relaxed font-light lg:text-right">
              Our certified coaches are more than trainers — they're transformation specialists who've been there and deliver results.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-5">
          {trainers.map((trainer, i) => (
            <TrainerCard key={trainer.name} {...trainer} delay={i * 100} inView={inView} />
          ))}
        </div>
      </div>
    </section>
  )
}

function TrainerCard({ name, role, exp, specialties, img, delay, inView }) {
  return (
    <div
      className={`group relative overflow-hidden transition-all duration-700 ${
        inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="relative overflow-hidden aspect-[3/4]">
        <img
          src={img}
          alt={name}
          className="w-full h-full object-cover grayscale group-hover:grayscale-[20%] group-hover:scale-105 transition-all duration-700"
          style={{ filter: 'sepia(10%) saturate(70%)' }}
        />
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-apex-charcoal/85 via-apex-charcoal/10 to-transparent" />

        {/* Experience badge */}
        <div className="absolute top-3 right-3 bg-apex-ivory/90 backdrop-blur-sm px-2.5 py-1">
          <span className="font-heading text-[9px] tracking-widest uppercase text-apex-charcoal">{exp}</span>
        </div>

        {/* Hover social */}
        <div className="absolute top-3 left-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-8 h-8 bg-apex-ivory/15 backdrop-blur-sm flex items-center justify-center hover:bg-apex-bronze transition-colors cursor-pointer">
            <Instagram size={11} className="text-apex-ivory" />
          </div>
        </div>

        {/* Bottom info */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className="font-display text-lg font-light text-apex-ivory mb-0.5">{name}</h3>
          <p className="font-heading text-[10px] tracking-wider uppercase text-apex-bronze/70 mb-3">{role}</p>
          <div className="flex flex-wrap gap-1 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-400">
            {specialties.map((s) => (
              <span key={s} className="font-heading text-[8px] tracking-wider uppercase bg-apex-ivory/12 text-apex-ivory/60 px-1.5 py-0.5">
                {s}
              </span>
            ))}
          </div>
        </div>

        {/* Bronze bottom line */}
        <div className="absolute bottom-0 left-0 w-full h-0.5 bg-apex-bronze scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
      </div>
    </div>
  )
}
