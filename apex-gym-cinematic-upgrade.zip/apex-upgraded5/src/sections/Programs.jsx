import { useInView } from '../hooks/useInView'
import { ArrowUpRight } from 'lucide-react'

const programs = [
  {
    id: '01',
    title: 'Strength & Conditioning',
    desc: 'Build raw power. Sculpt a physique built for performance. Our S&C program blends progressive overload with athletic conditioning.',
    tag: 'Most Popular',
    img: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=900&q=85',
  },
  {
    id: '02',
    title: 'HIIT & Metabolic',
    desc: 'High-intensity intervals engineered to maximise fat loss while preserving muscle. 45 minutes. Maximum output.',
    tag: 'Fat Loss',
    img: 'https://images.unsplash.com/photo-1549060279-7e168fcee0c2?w=900&q=85',
  },
  {
    id: '03',
    title: 'Elite Personal Training',
    desc: 'One trainer. One focus. Your transformation. Completely personalised programming delivered by certified elite coaches.',
    tag: 'Premium',
    img: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=900&q=85',
  },
  {
    id: '04',
    title: 'Combat & Boxing',
    desc: 'Discipline of the ring meets elite conditioning. Build agility, power, and mental resilience through authentic boxing training.',
    tag: 'High Intensity',
    img: 'https://images.unsplash.com/photo-1617859047452-8510bcf207fd?w=900&q=85',
  },
]

export default function Programs() {
  const [ref, inView] = useInView()

  return (
    <section id="programs" className="relative py-24 lg:py-40 overflow-hidden" ref={ref}>
      {/* Very subtle cinematic tonal background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-apex-ivory" />
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1400&q=40')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center 30%',
            filter: 'grayscale(100%)',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-apex-ivory via-apex-ivory/85 to-apex-ivory" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-16 relative z-10">

        {/* Header */}
        <div className={`flex flex-col lg:flex-row lg:items-end justify-between mb-14 gap-8 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div>
            <p className="section-label">Training Programs</p>
            <h2 className="section-title text-[clamp(3rem,6vw,6.5rem)] text-apex-charcoal leading-none">
              Classes<br />
              <em className="italic text-apex-bronze">Designed</em><br />
              For You
            </h2>
          </div>
          <p className="font-body text-sm text-apex-charcoal/55 max-w-xs leading-relaxed font-light lg:text-right">
            Each program is engineered by specialists for maximum results. Pick your path.
          </p>
        </div>

        {/* Grid */}
        <div className="grid lg:grid-cols-2 gap-3">
          {programs.map((prog, i) => (
            <ProgramCard key={prog.id} {...prog} delay={i * 80} inView={inView} />
          ))}
        </div>
      </div>
    </section>
  )
}

function ProgramCard({ id, title, desc, tag, img, delay, inView }) {
  return (
    <div
      className={`group relative overflow-hidden program-card cursor-pointer ${
        inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
      style={{ transitionDelay: `${delay}ms`, transition: 'opacity 0.7s ease, transform 0.7s ease, box-shadow 0.5s ease, border-color 0.4s ease' }}
    >
      {/* Full cinematic image — much stronger */}
      <div className="absolute inset-0 z-0">
        <img
          src={img}
          alt={title}
          className="w-full h-full object-cover opacity-[0.32] group-hover:opacity-[0.50] group-hover:scale-105 transition-all duration-700"
          style={{ filter: 'grayscale(25%) contrast(1.1)' }}
        />
        {/* Gradient: strong bottom, lighter top */}
        <div className="absolute inset-0 bg-gradient-to-t from-apex-ivory/98 via-apex-ivory/75 to-apex-ivory/30" />
        {/* Left vignette */}
        <div className="absolute inset-0 bg-gradient-to-r from-apex-ivory/60 to-transparent" />
      </div>

      {/* Hover glow accent */}
      <div className="absolute inset-0 z-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{ background: 'radial-gradient(ellipse at 30% 80%, rgba(139,110,78,0.06) 0%, transparent 60%)' }}
      />

      <div className="relative z-10 p-8 lg:p-10 min-h-[240px] flex flex-col justify-between">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <span className="font-heading text-[10px] text-apex-bronze/60 tracking-widest">{id}</span>
            {tag && (
              <span className="font-heading text-[9px] tracking-[0.2em] uppercase text-apex-bronze border border-apex-bronze/35 px-2 py-0.5">
                {tag}
              </span>
            )}
          </div>
          <div className="w-8 h-8 border border-apex-charcoal/12 flex items-center justify-center group-hover:bg-apex-charcoal group-hover:border-apex-charcoal transition-all duration-300">
            <ArrowUpRight size={12} className="text-apex-charcoal/30 group-hover:text-apex-ivory transition-colors" />
          </div>
        </div>

        <div>
          <h3 className="font-display text-2xl lg:text-3xl font-light text-apex-charcoal mb-3 group-hover:text-apex-bronze transition-colors duration-300">
            {title}
          </h3>
          <p className="font-body text-sm text-apex-charcoal/55 leading-relaxed font-light">{desc}</p>
        </div>
      </div>

      {/* Bottom bronze reveal */}
      <div className="absolute bottom-0 left-0 w-full h-0.5 bg-apex-bronze scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
    </div>
  )
}
