import { useEffect, useState } from 'react'
import { ArrowRight } from 'lucide-react'

const words = ['DISCIPLINE', 'STRENGTH', 'POWER', 'MASTERY']

export default function Hero() {
  const [wordIndex, setWordIndex] = useState(0)
  const [visible, setVisible] = useState(true)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    setTimeout(() => setLoaded(true), 120)
    const interval = setInterval(() => {
      setVisible(false)
      setTimeout(() => {
        setWordIndex((i) => (i + 1) % words.length)
        setVisible(true)
      }, 350)
    }, 3200)
    return () => clearInterval(interval)
  }, [])

  return (
    <section className="relative min-h-screen flex flex-col justify-end overflow-hidden hero-grain">
      {/* Hero image — cinematic, full bleed */}
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0 bg-cover bg-center scale-105"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1920&q=80&auto=format&fit=crop')`,
            filter: 'brightness(0.75) contrast(1.05)',
          }}
        />
        {/* Multi-layer cinematic gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-apex-ink/92 via-apex-ink/45 to-apex-ink/18" />
        <div className="absolute inset-0 bg-gradient-to-r from-apex-ink/30 via-transparent to-transparent" />
        {/* Warm bronze atmosphere */}
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 80% 20%, rgba(139,110,78,0.06) 0%, transparent 60%)' }} />
      </div>

      {/* Vertical editorial label — right edge */}
      <div className="absolute right-6 top-1/2 -translate-y-1/2 z-10 hidden xl:block">
        <p className="writing-vertical font-heading text-[9px] tracking-[0.45em] uppercase text-apex-ivory/20">
          Est. 2024 — Apex Fitness — New Delhi
        </p>
      </div>

      {/* Stats — architectural right panel */}
      <div className={`absolute top-1/2 -translate-y-1/2 right-8 lg:right-16 z-10 transition-all duration-1000 delay-800 ${
        loaded ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'
      }`}>
        <div className="flex flex-col gap-0 border-l border-apex-ivory/10">
          {[
            { num: '2,400+', label: 'Members' },
            { num: '48', label: 'Trainers' },
            { num: '12yr', label: 'Experience' },
          ].map(({ num, label }) => (
            <div key={label} className="text-right pl-5 py-4 border-b border-apex-ivory/8 last:border-b-0">
              <div className="font-display text-xl lg:text-2xl font-light text-apex-ivory/90">{num}</div>
              <div className="font-heading text-[8px] tracking-[0.35em] uppercase text-apex-ivory/28 mt-0.5">{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Main content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-16 pb-28 lg:pb-40">

        {/* Overline */}
        <div className={`transition-all duration-700 delay-200 ${loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          <div className="flex items-center gap-4 mb-8">
            <div className="w-8 h-px bg-apex-bronze/70" />
            <span className="font-heading text-[10px] tracking-[0.4em] uppercase text-apex-bronze/80">
              Premium Fitness — Delhi
            </span>
          </div>
        </div>

        {/* Headline */}
        <div className={`transition-all duration-700 delay-300 ${loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="section-title text-[clamp(4rem,12vw,11rem)] text-apex-ivory leading-[0.9]">
            FORGE YOUR
          </h1>
        </div>

        {/* Animated word */}
        <div className={`transition-all duration-700 delay-400 ${loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="section-title text-[clamp(4rem,12vw,11rem)] leading-[0.9] mb-10">
            <span className={`italic font-light transition-all duration-300 inline-block ${
              visible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'
            }`} style={{ color: '#C9A97A' }}>
              {words[wordIndex]}
            </span>
          </h1>
        </div>

        {/* Sub copy + CTAs */}
        <div className={`flex flex-col sm:flex-row items-start sm:items-end gap-8 transition-all duration-700 delay-500 ${
          loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <p className="font-body text-sm text-apex-ivory/55 max-w-xs leading-relaxed font-light">
            Elite training. Proven results. A community built on discipline and transformation.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 sm:ml-10">
            <button
              onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
              className="hero-btn-primary inline-flex items-center gap-3 bg-apex-ivory text-apex-charcoal font-heading font-light tracking-[0.2em] uppercase text-xs px-8 py-4 transition-all duration-400"
            >
              Join Now <ArrowRight size={12} />
            </button>
            <button
              onClick={() => document.getElementById('programs')?.scrollIntoView({ behavior: 'smooth' })}
              className="hero-btn-outline inline-flex items-center gap-3 border border-apex-ivory/20 text-apex-ivory font-heading font-light tracking-[0.2em] uppercase text-xs px-8 py-4 transition-all duration-400"
            >
              Our Programs
            </button>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <button
        onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-3 group"
      >
        <span className="font-heading text-[9px] tracking-[0.4em] uppercase text-apex-ivory/25 group-hover:text-apex-ivory/55 transition-colors">
          Scroll
        </span>
        <div className="w-px h-10 bg-gradient-to-b from-apex-ivory/20 to-transparent" />
      </button>

      {/* Bottom feather */}
      <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-apex-ivory to-transparent z-10" />
    </section>
  )
}
