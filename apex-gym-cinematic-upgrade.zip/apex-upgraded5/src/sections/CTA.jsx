import { useInView } from '../hooks/useInView'
import { ArrowRight, MessageCircle } from 'lucide-react'

export default function CTA() {
  const [ref, inView] = useInView({ threshold: 0.2 })

  const whatsapp = () => {
    window.open('https://wa.me/919999999999?text=Hi%20APEX!%20I%20want%20to%20start%20my%20fitness%20journey.', '_blank')
  }

  return (
    <section className="relative py-40 lg:py-64 overflow-hidden" ref={ref}>
      {/* Full-bleed dark background image */}
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1920&q=80')` }}
        />
        <div className="absolute inset-0 bg-apex-charcoal/80" />
        {/* Warm bronze shimmer */}
        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-px bg-gradient-to-r from-transparent via-apex-bronze/20 to-transparent" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 lg:px-12 text-center">
        <div className={`transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <p className="section-label" style={{ color: 'rgba(201,169,122,0.7)' }}>Begin Today</p>
        </div>

        <div className={`transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h2 className="section-title text-[clamp(3.5rem,10vw,10rem)] text-apex-ivory leading-none mb-8">
            Your Strongest<br />
            <em className="italic" style={{ color: '#C9A97A' }}>Version</em><br />
            Starts Today.
          </h2>
        </div>

        <div className={`transition-all duration-700 delay-200 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <p className="font-body text-sm text-apex-ivory/60 max-w-md mx-auto leading-loose mb-14 font-light">
            Spots are limited. Elite coaching, premium facilities, and a community that demands the best from you. Don't wait.
          </p>
        </div>

        <div className={`flex flex-col sm:flex-row items-center justify-center gap-4 transition-all duration-700 delay-300 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <button
            onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
            className="inline-flex items-center gap-3 bg-apex-ivory hover:bg-apex-cream text-apex-charcoal font-heading font-light tracking-[0.2em] uppercase text-xs py-5 px-10 transition-all duration-300"
            style={{ boxShadow: '0 2px 20px rgba(0,0,0,0.3)' }}
          >
            Claim Your Spot <ArrowRight size={12} />
          </button>

          <button
            onClick={whatsapp}
            className="flex items-center gap-3 border border-apex-ivory/15 hover:border-apex-ivory/35 text-apex-ivory/70 hover:text-apex-ivory font-heading text-xs tracking-[0.2em] uppercase py-5 px-10 transition-all duration-300"
          >
            <MessageCircle size={14} className="text-green-400/70" />
            WhatsApp Us
          </button>
        </div>

        {/* Social proof */}
        <div className={`mt-14 flex items-center justify-center gap-6 transition-all duration-700 delay-400 ${inView ? 'opacity-100' : 'opacity-0'}`}>
          <div className="flex -space-x-2">
            {[
              'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=100&q=80',
              'https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=100&q=80',
              'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&q=80',
              'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=100&q=80',
            ].map((src, i) => (
              <img key={i} src={src} alt="" className="w-8 h-8 rounded-full border-2 border-apex-charcoal/60 object-cover grayscale" />
            ))}
          </div>
          <p className="font-body text-xs text-apex-ivory/30">
            <span className="text-apex-ivory/55 font-medium">2,400+ members</span> already transforming
          </p>
        </div>
      </div>
    </section>
  )
}
