import { MessageCircle } from 'lucide-react'

export default function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/919999999999?text=Hi%20APEX!%20I%20want%20to%20start%20my%20fitness%20journey."
      target="_blank"
      rel="noreferrer"
      className="fixed bottom-8 right-8 z-50 group flex items-center gap-3 bg-apex-charcoal text-apex-ivory px-4 py-3 transition-all duration-300 hover:bg-apex-ink"
      style={{ boxShadow: '0 4px 20px rgba(44,42,39,0.18)' }}
    >
      <MessageCircle size={14} className="text-green-400" />
      <span className="font-heading text-[10px] tracking-[0.2em] uppercase hidden sm:block">WhatsApp</span>
    </a>
  )
}
