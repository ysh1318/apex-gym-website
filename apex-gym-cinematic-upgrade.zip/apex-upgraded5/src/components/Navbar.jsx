import { useState, useEffect } from 'react'
import { Menu, X } from 'lucide-react'

const navItems = ['About', 'Programs', 'Pricing', 'Trainers', 'Schedule']

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [heroSection, setHeroSection] = useState(true)

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 60)
      setHeroSection(window.scrollY < window.innerHeight * 0.7)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const scrollTo = (id) => {
    document.getElementById(id.toLowerCase())?.scrollIntoView({ behavior: 'smooth' })
    setMenuOpen(false)
  }

  const isLight = !heroSection || scrolled

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-apex-ivory/96 backdrop-blur-md border-b border-apex-charcoal/6 shadow-inset-top'
          : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-6 lg:px-16">
          <div className="flex items-center justify-between h-16 lg:h-20">

            {/* Logo */}
            <a href="#" className="flex items-center gap-3 group">
              <div className="w-7 h-7 border border-apex-bronze/60 flex items-center justify-center group-hover:bg-apex-bronze/10 transition-colors">
                <span className="font-display text-apex-bronze text-xs font-light tracking-wider">A</span>
              </div>
              <span className={`font-display text-2xl tracking-[0.18em] font-light transition-colors duration-500 ${
                isLight ? 'text-apex-charcoal' : 'text-apex-ivory'
              }`}>
                APEX
              </span>
            </a>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-10">
              {navItems.map((item) => (
                <button key={item} onClick={() => scrollTo(item)} className={`font-heading text-[11px] tracking-[0.25em] uppercase transition-colors duration-300 ${
                  isLight ? 'text-apex-charcoal/60 hover:text-apex-charcoal' : 'text-apex-ivory/70 hover:text-apex-ivory'
                }`}>
                  {item}
                </button>
              ))}
            </div>

            {/* CTA */}
            <div className="hidden lg:flex items-center gap-4">
              <button onClick={() => scrollTo('pricing')} className={`font-heading text-[10px] tracking-[0.22em] uppercase px-6 py-3 border transition-all duration-300 ${
                isLight
                  ? 'border-apex-charcoal/25 text-apex-charcoal hover:bg-apex-charcoal hover:text-apex-ivory'
                  : 'border-apex-ivory/30 text-apex-ivory hover:bg-apex-ivory hover:text-apex-charcoal'
              }`}>
                Join Now
              </button>
            </div>

            {/* Mobile toggle */}
            <button onClick={() => setMenuOpen(!menuOpen)} className={`lg:hidden p-2 transition-colors ${isLight ? 'text-apex-charcoal' : 'text-apex-ivory'}`}>
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div className={`fixed inset-0 z-40 bg-apex-ivory transition-all duration-500 flex flex-col justify-center px-10 lg:hidden ${
        menuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
      }`}>
        {/* Close button — always visible inside the overlay */}
        <button
          onClick={() => setMenuOpen(false)}
          className="absolute top-5 right-6 p-2 text-apex-charcoal/60 hover:text-apex-charcoal transition-colors"
          aria-label="Close menu"
        >
          <X size={22} />
        </button>

        {/* Decorative vertical line */}
        <div className="absolute left-10 top-28 bottom-28 w-px bg-apex-charcoal/6" />

        <div className="flex flex-col gap-8 pl-8">
          {navItems.map((item, i) => (
            <button
              key={item}
              onClick={() => scrollTo(item)}
              className="font-display text-5xl font-light text-left text-apex-charcoal/70 hover:text-apex-charcoal transition-colors tracking-tight"
              style={{ transitionDelay: `${i * 40}ms` }}
            >
              {item}
            </button>
          ))}
          <button onClick={() => scrollTo('pricing')} className="btn-primary mt-2 w-fit">
            Join APEX
          </button>
        </div>

        <div className="absolute bottom-12 left-10 right-10">
          <div className="rule-solid mb-6" />
          <div className="flex items-center gap-6">
            {['Instagram', 'Facebook', 'YouTube'].map((s) => (
              <a key={s} href="#" className="font-heading text-[10px] tracking-[0.25em] text-apex-charcoal/35 hover:text-apex-bronze uppercase transition-colors">
                {s}
              </a>
            ))}
          </div>
        </div>
      </div>
    </>
  )
}
