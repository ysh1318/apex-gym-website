import { Instagram, Facebook, Youtube, MapPin, Phone, Mail, ArrowUpRight } from 'lucide-react'

const navLinks = [
  { label: 'About', href: '#about' },
  { label: 'Programs', href: '#programs' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Trainers', href: '#trainers' },
  { label: 'Schedule', href: '#schedule' },
]

const legalLinks = ['Privacy Policy', 'Terms of Service', 'Refund Policy']

export default function Footer() {
  const scrollTo = (id) => document.querySelector(id)?.scrollIntoView({ behavior: 'smooth' })

  return (
    <footer className="bg-apex-charcoal">
      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-6 lg:px-16 py-20">
        <div className="grid lg:grid-cols-4 gap-14">

          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-7 h-7 border border-apex-bronze/40 flex items-center justify-center">
                <span className="font-display text-apex-bronze text-xs font-light">A</span>
              </div>
              <span className="font-display text-2xl tracking-[0.18em] font-light text-apex-ivory">APEX</span>
            </div>
            <p className="font-body text-sm text-apex-ivory/40 leading-loose max-w-sm mb-8 font-light">
              Premium fitness for the disciplined. Built for those who refuse mediocrity and demand transformation.
            </p>

            <div className="flex gap-3">
              {[Instagram, Facebook, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 border border-apex-ivory/8 flex items-center justify-center text-apex-ivory/50 hover:text-apex-bronze hover:border-apex-bronze/30 transition-all duration-200"
                >
                  <Icon size={13} />
                </a>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-heading text-[10px] tracking-[0.3em] uppercase text-apex-ivory/35 mb-6">Navigate</h4>
            <ul className="flex flex-col gap-3">
              {navLinks.map(({ label, href }) => (
                <li key={label}>
                  <a
                    href={href}
                    onClick={(e) => { e.preventDefault(); scrollTo(href) }}
                    className="font-heading text-xs tracking-wider text-apex-ivory/55 hover:text-apex-bronze transition-colors duration-200 group flex items-center gap-2"
                  >
                    {label}
                    <ArrowUpRight size={9} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-heading text-[10px] tracking-[0.3em] uppercase text-apex-ivory/35 mb-6">Contact</h4>
            <ul className="flex flex-col gap-4">
              <li>
                <a href="https://maps.google.com" target="_blank" rel="noreferrer"
                  className="flex items-start gap-3 text-apex-ivory/50 hover:text-apex-ivory/60 transition-colors group">
                  <MapPin size={11} className="mt-0.5 shrink-0 text-apex-bronze/50" />
                  <span className="font-body text-xs leading-relaxed font-light">
                    42 Elite Sports Complex,<br />Connaught Place, New Delhi
                  </span>
                </a>
              </li>
              <li>
                <a href="tel:+919999999999" className="flex items-center gap-3 text-apex-ivory/50 hover:text-apex-ivory/60 transition-colors">
                  <Phone size={11} className="shrink-0 text-apex-bronze/50" />
                  <span className="font-body text-xs font-light">+91 99999 99999</span>
                </a>
              </li>
              <li>
                <a href="mailto:elite@apexfit.in" className="flex items-center gap-3 text-apex-ivory/50 hover:text-apex-ivory/60 transition-colors">
                  <Mail size={11} className="shrink-0 text-apex-bronze/50" />
                  <span className="font-body text-xs font-light">elite@apexfit.in</span>
                </a>
              </li>
            </ul>

            <div className="mt-8 p-4 border border-apex-ivory/5 bg-apex-ink/30">
              <p className="font-heading text-[9px] tracking-wider uppercase text-apex-ivory/35 mb-1">Hours</p>
              <p className="font-body text-xs text-apex-ivory/55 font-light">Mon–Fri: 5AM – 11PM</p>
              <p className="font-body text-xs text-apex-ivory/55 font-light">Sat–Sun: 6AM – 9PM</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-apex-ivory/4">
        <div className="max-w-7xl mx-auto px-6 lg:px-16 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-body text-[10px] text-apex-ivory/15 font-light">
            © 2025 APEX FITNESS. All rights reserved.
          </p>
          <div className="flex gap-6">
            {legalLinks.map((link) => (
              <a key={link} href="#" className="font-heading text-[9px] tracking-wider uppercase text-apex-ivory/15 hover:text-apex-ivory/40 transition-colors">
                {link}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
