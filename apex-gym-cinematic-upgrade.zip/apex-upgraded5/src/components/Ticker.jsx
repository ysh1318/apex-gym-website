export default function Ticker() {
  const baseItems = [
    'Discipline', '—', 'Strength', '—', 'Transform', '—',
    'Elite Coaching', '—', 'Consistency', '—', 'Results', '—',
  ]
  // Quadruple to ensure seamless wrap across all viewport sizes
  const items = [...baseItems, ...baseItems, ...baseItems, ...baseItems]

  return (
    <div className="relative bg-apex-charcoal py-3.5 overflow-hidden z-10">
      <div className="ticker-wrap">
        <div className="ticker-content">
          {items.map((item, i) => (
            <span
              key={i}
              className={`inline-block mx-7 font-heading text-[11px] tracking-[0.25em] uppercase ${
                item === '—' ? 'text-apex-bronze/40 text-xs' : 'text-apex-ivory/80'
              }`}
            >
              {item}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
