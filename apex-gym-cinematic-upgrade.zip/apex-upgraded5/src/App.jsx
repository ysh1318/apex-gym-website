import Navbar from './components/Navbar'
import CustomCursor from './components/CustomCursor'
import WhatsAppButton from './components/WhatsAppButton'
import Ticker from './components/Ticker'
import Footer from './components/Footer'

import Hero from './sections/Hero'
import About from './sections/About'
import Stats from './sections/Stats'
import Programs from './sections/Programs'
import Gallery from './sections/Gallery'
import Trainers from './sections/Trainers'
import Pricing from './sections/Pricing'
import Testimonials from './sections/Testimonials'
import Schedule from './sections/Schedule'
import CTA from './sections/CTA'

export default function App() {
  return (
    <div className="relative bg-apex-ivory min-h-screen">
      <CustomCursor />
      <Navbar />
      <main>
        <Hero />
        <Ticker />
        <About />
        <Stats />
        <Programs />
        <Gallery />
        <Trainers />
        <Pricing />
        <Testimonials />
        <Schedule />
        <CTA />
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  )
}
