/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        'display': ['"Cormorant Garamond"', 'Georgia', 'serif'],
        'heading': ['"Josefin Sans"', 'sans-serif'],
        'body': ['"DM Sans"', 'sans-serif'],
      },
      colors: {
        'apex': {
          'ivory':    '#F7F4EF',   // warm ivory — primary bg
          'cream':    '#EDE9E2',   // deeper warm cream
          'stone':    '#D6CFC4',   // muted stone
          'parchment':'#C9C0B3',   // architectural parchment
          'charcoal': '#2C2A27',   // rich charcoal — primary text
          'ink':      '#1A1916',   // near-black ink
          'bronze':   '#8B6E4E',   // restrained bronze accent
          'copper':   '#A07850',   // warm copper highlight
          'fog':      '#8A857D',   // muted fog for secondary text
          'white':    '#FDFCFA',   // warm near-white
        }
      },
      boxShadow: {
        'architectural': '0 1px 3px rgba(44,42,39,0.06), 0 8px 32px rgba(44,42,39,0.08)',
        'editorial':     '0 2px 8px rgba(44,42,39,0.05), 0 24px 64px rgba(44,42,39,0.12)',
        'deep':          '0 4px 16px rgba(44,42,39,0.08), 0 40px 80px rgba(44,42,39,0.15)',
        'inset-top':     'inset 0 1px 0 rgba(44,42,39,0.06)',
      },
      transitionDuration: {
        '400': '400ms',
        '600': '600ms',
        '800': '800ms',
      },
      transitionDelay: {
        '150': '150ms',
        '400': '400ms',
        '800': '800ms',
      },
      animation: {
        'fade-up':   'fadeUp 0.9s cubic-bezier(0.16,1,0.3,1) forwards',
        'fade-in':   'fadeIn 1.1s ease forwards',
        'ticker':    'ticker 35s linear infinite',
      },
      keyframes: {
        fadeUp: {
          '0%':   { opacity: '0', transform: 'translateY(36px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        ticker: {
          '0%':   { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-25%)' },
        },
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
      },
    },
  },
  plugins: [],
}
