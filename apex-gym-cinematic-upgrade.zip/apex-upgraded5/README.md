# APEX — Premium Fitness Website

A cinematic, luxury gym website inspired by elite sports branding and modern Dribbble fitness concepts.

## Tech Stack
- **React 18** + **Vite 5**
- **Tailwind CSS 3**
- **Framer Motion** (ready to use)
- **Lucide React** icons

## Design System
- **Typography**: Bebas Neue (display), Oswald (headings), Montserrat (body)
- **Colors**: Matte black (#0a0a0a), Deep red (#c0392b), Orange glow (#e67e22)
- **Aesthetic**: Cinematic dark luxury — Nike-meets-editorial

## Getting Started

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Project Structure

```
apex-gym/
├── public/
│   └── favicon.svg
├── src/
│   ├── components/
│   │   ├── Navbar.jsx        # Sticky transparent → dark nav
│   │   ├── CustomCursor.jsx  # Red dot + ring cursor (desktop)
│   │   ├── WhatsAppButton.jsx # Floating WhatsApp CTA
│   │   ├── Ticker.jsx        # Animated marquee strip
│   │   └── Footer.jsx        # Premium minimal footer
│   ├── sections/
│   │   ├── Hero.jsx          # Fullscreen cinematic hero
│   │   ├── About.jsx         # Brand philosophy
│   │   ├── Stats.jsx         # Animated counters
│   │   ├── Programs.jsx      # Training programs grid
│   │   ├── Gallery.jsx       # Masonry transformation gallery
│   │   ├── Trainers.jsx      # Editorial trainer cards
│   │   ├── Pricing.jsx       # Premium membership cards
│   │   ├── Testimonials.jsx  # Glassmorphism reviews
│   │   ├── Schedule.jsx      # Futuristic class timetable
│   │   └── CTA.jsx           # High-conversion final CTA
│   ├── hooks/
│   │   └── useInView.js      # Scroll reveal + counter hooks
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css             # Global styles + animations
├── tailwind.config.js
├── vite.config.js
└── package.json
```

## Customization

### Brand Colors
Edit `tailwind.config.js` → `theme.extend.colors.apex`

### Content
- Trainers: `src/sections/Trainers.jsx` → `trainers` array
- Programs: `src/sections/Programs.jsx` → `programs` array  
- Pricing: `src/sections/Pricing.jsx` → `plans` array
- Schedule: `src/sections/Schedule.jsx` → `schedule` object
- Contact: `src/components/Footer.jsx` + `src/sections/CTA.jsx`
- WhatsApp number: `src/components/WhatsAppButton.jsx` + `src/sections/CTA.jsx`

### Images
Replace Unsplash URLs with your own photography for a fully branded experience.

## Features
- ✅ Fullscreen cinematic hero with animated headline rotation
- ✅ Animated scroll-reveal on every section
- ✅ Animated stat counters
- ✅ Grayscale-to-color trainer card hover
- ✅ Premium pricing cards with glow effect
- ✅ Glassmorphism testimonial cards
- ✅ Interactive weekly class schedule
- ✅ Cinematic grain overlay
- ✅ Custom red cursor (desktop)
- ✅ Sticky WhatsApp floating button
- ✅ Animated scroll marquee ticker
- ✅ Mobile-first fully responsive
- ✅ Smooth scrolling navigation
